# Fluxzee — Guia de Identidade Visual
## Vertical: Hotelaria Independente

### 01 — Paleta de Cores

| Nome | Hex | Uso |
|------|-----|-----|
| Verde Base | #0d2b20 | Fundo principal |
| Laranja | #e8600a | CTAs e impacto |
| Verde Neon | #00c96e | Destaques |
| Creme | #f5f0e8 | Posts educativos |
| Verde Médio | #1a3d2b | Variação escura |

**Regra:** Amarelo #f5c842 NÃO aparece em conteúdos de hotelaria.

### 02 — Logo

- fluxzee-logo-positivo.svg → fundo claro
- fluxzee-logo-negativo.svg → fundo escuro (dark mode)
- fluxzee-logo-animado.svg → versão com íons animados (digital)

### 03 — Tipografia

- Headlines: Arial Black / Syne 800 — maiúsculas, bold, compacto
- Corpo: Inter / Helvetica — 400/500

### 04 — Tom Visual

- Posts de impacto: fundo laranja ou verde escuro, tipografia máxima
- Posts educativos: fundo creme ou verde escuro, hierarquia clara
- Sempre: tag de categoria + headline + conteúdo + CTA

### 05 — Marca

Nome: Fluxzee (sem subtítulo)
O contexto de hotelaria aparece no conteúdo, não no nome.
